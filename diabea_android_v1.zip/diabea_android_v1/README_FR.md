# Diabéa — première version de travail Android (v1.1)

Cette archive est le code source d'une application éducative sur le diabète, prévue pour être emballée dans une application Android avec Capacitor. **Ce n'est pas encore un APK compilé.**

## Fonctionnalités présentes dans cette version
- Tableau de bord avec raccourcis clairs et grands boutons.
- Interface en français, texte lisible et option pour agrandir la police.
- Assistant éducatif à réponses prédéfinies détaillées ; il ne s'agit pas encore d'une IA connectée.
- Lecture vocale via les fonctions disponibles dans le navigateur / Android, avec test, pause, reprise et arrêt ; son fonctionnement dépend de l'appareil et du moteur vocal installé.
- Dictée vocale si le navigateur la prend en charge.
- Réponses visibles qui s'effacent automatiquement après 2 minutes ; l'historique reste consultable localement.
- Carnet local de glycémie avec possibilité de supprimer les mesures.
- Leçons éducatives et informations d'urgence.
- Rappels simples dans l'application. Dans cette version, l'application doit rester ouverte pour déclencher le rappel ; les notifications Android en arrière-plan ne sont pas encore garanties.
- Fichiers de base pour une PWA et configuration Capacitor.

## Tester sur téléphone
Ouvre `www/index.html` dans un navigateur pour tester l'interface. Les fonctions d'installation PWA et le service worker exigent HTTPS ou un serveur local ; ouvrir le fichier directement ne suffit pas. Le microphone et la lecture vocale dépendent de la version Android, du navigateur, des autorisations et du moteur de synthèse vocale.

## Générer gratuitement un APK avec un ordinateur
1. Installer Node.js LTS et Android Studio depuis leurs sites officiels.
2. Décompresser cette archive et ouvrir un terminal dans le dossier `diabea_android_v1`.
3. Exécuter `npm install`.
4. Exécuter `npx cap add android` (une seule fois).
5. Exécuter `npx cap sync android`.
6. Exécuter `npx cap open android`.
7. Dans Android Studio, utiliser **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
8. Installer et tester l'APK avant toute diffusion.

## Ce qui reste à faire avant une vraie diffusion
- Tester sur plusieurs téléphones Android, notamment la lecture vocale et les rappels.
- Ajouter les notifications Android natives si elles sont nécessaires.
- Ajouter une IA connectée seulement après avoir choisi un fournisseur et protégé la clé API côté serveur. Une IA connectée peut avoir un coût ; ne pas intégrer de clé secrète dans le code mobile.
- Faire relire les contenus médicaux par des professionnels de santé.
- Définir une politique de confidentialité et tester la sécurité des données de santé.

## Sécurité et confidentialité
Diabéa informe et éduque ; il ne diagnostique pas et ne prescrit pas. Ne modifie pas un traitement sur la base de l'application. Les recherches, mesures, préférences et rappels sont stockés localement sur l'appareil. Ils peuvent être perdus si les données de l'application ou du navigateur sont effacées. Ne saisis pas de données permettant d'identifier une personne.

## Budget
Les outils de développement de base sont gratuits. La génération de l'APK nécessite généralement un ordinateur et le téléchargement de composants Android. Les services IA hébergés, l'hébergement et la publication sur certaines boutiques peuvent entraîner des coûts ultérieurs ; cette version ne dépend pas encore d'une IA distante.
